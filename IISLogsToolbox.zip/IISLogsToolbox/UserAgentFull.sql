SELECT
	cs(User-Agent) as UserAgent,
	COUNT(*) as Hits
FROM
	ex\*.log
GROUP BY
	UserAgent