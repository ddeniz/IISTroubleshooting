SELECT 
    sc-status as Status, 
	COUNT(*) as Hits, 
    MUL(PROPCOUNT(*),100) as % 
FROM 
    ex\*.log 
GROUP BY 
    sc-status
