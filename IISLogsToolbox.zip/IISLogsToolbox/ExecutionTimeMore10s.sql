SELECT
	cs-uri-stem as Url,
	AVG(time-taken) as AverageExecutionTime,
	COUNT(*) as Hits
FROM
	ex\*.log
WHERE
	NOT(sc-status = 500)
	AND time-taken > '10000'
GROUP BY
	Url
ORDER BY
	Hits DESC
