SELECT
		SUBSTR(cs(User-Agent), INDEX_OF(cs(User-Agent), 'MSIE'), 6) as IE,
		COUNT(*) as Hits
FROM
	ex\*.log

GROUP BY
	IE