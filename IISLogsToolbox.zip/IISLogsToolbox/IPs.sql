SELECT
		DISTINCT c-ip as IP, count(*) as Hits
FROM
	ex\*.log
GROUP BY
	c-ip