SELECT
		count(DISTINCT c-ip) as UniqueIPs
FROM
	ex\*.log